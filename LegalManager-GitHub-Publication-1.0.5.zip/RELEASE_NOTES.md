# LegalManager HTML Single User – Free 1.0.5

Versione gratuita di valutazione.

### Credenziali primo avvio

**Utente:** `Legal`  
**Password:** `Manager`

Al primo avvio è obbligatorio impostare nuove credenziali.

⚠️ **Dopo la modifica, le credenziali non sono modificabili nella versione Free.**

### Importante

I dati della versione Free vengono conservati localmente e **non sono cifrati**.

Per versioni Desktop Professional:
**paolohc64@gmail.com**

## Download

Scaricare l'asset:

`LegalManagerHTML-SingleUser-1.0.5-Desktop.zip`

# Changelog

## 1.0.5 – Free / Evaluation

- Installer Windows corretto.
- Creazione del collegamento sul Desktop tramite percorso Desktop rilevato direttamente da Windows.
- Collegamento associato al launcher `Avvia LegalManager.bat`.
- Icona LegalManager associata al collegamento.
- Installazione locale nella cartella `%LOCALAPPDATA%\LegalManagerHTML`.
- Versione Single User con funzioni Professional non disponibili nell'interfaccia.
- Backup e import/export disponibili.
- Dati locali non cifrati: versione destinata alla valutazione.

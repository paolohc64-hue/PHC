# LegalManager HTML – Single User Free

**Versione 1.0.5 – Free / Evaluation**

LegalManager HTML Single User è una versione locale e gratuita di valutazione di LegalManager.

## Caratteristiche

- utilizzo singolo utente;
- funzionamento locale nel browser;
- nessun server richiesto;
- nessuna connessione NAS;
- gestione locale di assistiti, pratiche, agenda, documenti e altre funzioni previste dall'interfaccia;
- backup;
- importazione/esportazione dei dati, cartelle e documenti;
- installazione con collegamento sul Desktop e icona LegalManager;
- funzioni avanzate riservate alla versione Desktop Professional.

## ⚠️ Importante: protezione dei dati

Questa versione **Free / Evaluation non cifra i dati locali**.

È quindi consigliata come versione di prova. Per l'utilizzo professionale e per le funzionalità avanzate di sicurezza è disponibile la versione Desktop Professional.

## Primo avvio

Le credenziali iniziali sono:

- **Utente:** `Legal`
- **Password:** `Manager`

Al primo avvio è richiesto di sostituire le credenziali predefinite.

**ATTENZIONE:** nella versione Free le credenziali impostate dopo il primo accesso **non possono essere modificate dall'applicazione**. Le sezioni Utenti e Collaboratori sono riservate alla versione Desktop Professional.

Conservare quindi con cura le nuove credenziali.

## Installazione

1. Scaricare `LegalManagerHTML-SingleUser-1.0.5-Desktop.zip`.
2. Estrarre completamente il contenuto dello ZIP.
3. Eseguire `Installa LegalManager sul Desktop.bat`.
4. Verrà creato il collegamento **LegalManager HTML** sul Desktop.
5. Avviare l'applicazione dal collegamento.

L'applicazione viene installata nella cartella locale dell'utente:

`%LOCALAPPDATA%\LegalManagerHTML`

## Versione Professional

Le funzionalità Desktop Professional comprendono le funzioni non disponibili nella versione Free, incluse le funzionalità avanzate per utenti/collaboratori, multiutenza e sicurezza.

Per informazioni sulle versioni Professional:

**paolohc64@gmail.com**

## Licenza

Questa distribuzione è una versione gratuita di valutazione di LegalManager. Il copyright e i diritti sul software restano ai rispettivi titolari. La licenza di distribuzione della versione Free è descritta nel file `LICENSE.txt`.
